"""End-to-end smoke test for BVTech Pulse v0.1.
Run from the pulse/ dir with a dev .env (sqlite is fine):
    python scripts/smoke_test.py
"""
import sys, os
sys.path.insert(0, os.getcwd())
from fastapi.testclient import TestClient
from app.main import app

def main():
    with TestClient(app) as c:
        assert c.get("/api/health").json()["ok"], "health failed"
        pw = os.environ.get("BOOTSTRAP_ADMIN_PASSWORD", "")
        r = c.post("/api/auth/login", json={"email": os.environ.get("BOOTSTRAP_ADMIN_EMAIL","admin@bvtech.org"), "password": pw})
        assert r.status_code == 200, f"login failed: {r.text}"
        cid = c.post("/api/clients", json={"name":"Smoke Test Co"}).json()["id"]
        c.post("/api/licenses", json={"client_id":cid,"product":"M365 Business Premium","seats":10})
        tok = c.post(f"/api/agent/enroll-token/{cid}").json()["enroll_token"]

        a = TestClient(app); a.cookies.clear()
        ent = a.post("/api/agent/enroll", json={"enroll_token":tok,"hostname":"SMOKE-PC","os":"Windows 11"}).json()
        ci = a.post("/api/agent/checkin",
                    headers={"X-Enroll-Id":ent["enroll_id"],"X-Agent-Key":ent["agent_key"]},
                    json={"cpu_pct":20,"ram_pct":40,"disk_pct":95,"av_status":"on","patch_status":"behind"})
        assert ci.status_code == 200, ci.text
        devs = c.get("/api/devices").json()
        assert any(d["hostname"]=="SMOKE-PC" for d in devs), "device not visible"
        assert any(a_["action"]=="agent.enrolled" for a_ in c.get("/api/audit?limit=20").json()), "audit missing"

        n = TestClient(app); n.cookies.clear()
        assert n.get("/api/clients").status_code == 401, "unauth not blocked"
    print("SMOKE TEST PASSED ✓")

if __name__ == "__main__":
    main()
